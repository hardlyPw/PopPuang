package dongne.poppuang;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PoppuangApplicationTests {

	@Test
	void contextLoads() {
	}

}
